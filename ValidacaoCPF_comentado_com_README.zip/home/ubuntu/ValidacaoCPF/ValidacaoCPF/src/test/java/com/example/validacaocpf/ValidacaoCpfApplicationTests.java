package com.example.validacaocpf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidacaoCpfApplicationTests {

	@Test
	void contextLoads() {
	}

}
