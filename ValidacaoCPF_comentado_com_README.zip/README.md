# ✅ Projeto Validação de CPF

Este projeto Java tem como objetivo realizar a **validação de CPF** (Cadastro de Pessoa Física), aplicando as regras oficiais da Receita Federal para verificar se um número informado é válido.

---

## 🎯 Objetivo

Fornecer uma ferramenta backend confiável que:
- Valida a estrutura e os dígitos verificadores de um CPF
- Rejeita CPFs inválidos ou com formatação incorreta
- Pode ser integrado em APIs, sistemas de cadastro, etc.

---

## 📚 Tecnologias Utilizadas

- Java 8 ou superior
- Spring Boot (opcional, se integrado com API)
- JUnit (para testes)
- Maven ou Gradle (build)

---

## ⚙️ Lógica de Validação

A validação segue as regras do CPF:
1. Ignora entradas com todos os dígitos iguais (ex: `111.111.111-11`)
2. Calcula o **primeiro dígito verificador** com os 9 primeiros dígitos
3. Calcula o **segundo dígito verificador** com os 10 primeiros dígitos
4. Compara os dois dígitos finais com os valores fornecidos

---

## 📦 Estrutura do Projeto

```
src/
├── main/
│   └── java/
│       └── br/
│           └── com/
│               └── validacao/
│                   ├── ValidacaoCpfApplication.java
│                   └── utils/
│                       └── CpfValidator.java
├── test/
│   └── java/
│       └── br/
│           └── com/
│               └── validacao/
│                   └── CpfValidatorTests.java
```

---

## 🧪 Exemplo de Uso

```java
boolean resultado = CpfValidator.isValid("123.456.789-09");
System.out.println(resultado); // false
```

---

## 🧪 Testes

Este projeto pode incluir testes automatizados com JUnit para verificar a lógica com vários cenários:

```java
@Test
void deveValidarCpfValido() {
    assertTrue(CpfValidator.isValid("529.982.247-25"));
}
```

---

## 🚀 Como Executar

1. Clone o projeto:
```bash
git clone https://github.com/seu-usuario/validador-cpf.git
```

2. Compile e execute:
```bash
mvn compile
mvn exec:java
```

---

## ✍️ Autor

Projeto criado com apoio do ChatGPT (OpenAI) para fins educacionais e uso prático em sistemas reais.

---

## 📄 Licença

Este projeto está sob a licença MIT.
